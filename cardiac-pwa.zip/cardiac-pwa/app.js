// app.js

// --- Declare the client variable in the global scope ---
var client = null;

document.addEventListener('DOMContentLoaded', () => {

    // --- PWA Service Worker Registration ---
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js')
            .then(reg => console.log('Service Worker registered successfully'))
            .catch(err => console.error('Service Worker registration failed:', err));
    }

    // --- Page Navigation ---
    const navLinks = document.querySelectorAll('nav a');
    const pages = document.querySelectorAll('.page');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetPageId = link.getAttribute('data-page');
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            pages.forEach(page => {
                page.id === `${targetPageId}-page` ? page.classList.remove('hidden') : page.classList.add('hidden');
            });
        });
    });

    // --- UI Element References ---
    const cadStatusEl = document.getElementById('cad-status');
    const toastEl = document.getElementById('toast-notification');
    const connectBtn = document.getElementById('connect-btn');
    const brokerAddressInput = document.getElementById('broker-address-input');
    const mqttStatusEl = document.getElementById('mqtt-connection-status');

    // --- Chart.js Setup for ECG ---
    const ecgCtx = document.getElementById('ecgChart').getContext('2d');
    const MAX_DATA_POINTS = 100; // Display more points for a smoother stream
    const ecgChart = new Chart(ecgCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'ECG',
                data: [],
                borderColor: 'rgb(255, 99, 132)',
                borderWidth: 1.5,
                pointRadius: 0,
                tension: 0.2
            }]
        },
        options: {
            animation: { duration: 250 },
            scales: { x: { display: false }, y: { beginAtZero: false } },
            plugins: { legend: { display: true } }
        }
    });

    function addDataToChart(chart, label, data) {
        chart.data.labels.push(label);
        chart.data.datasets.forEach(dataset => dataset.data.push(data));

        if (chart.data.labels.length > MAX_DATA_POINTS) {
            chart.data.labels.shift();
            chart.data.datasets.forEach(dataset => dataset.data.shift());
        }
        chart.update();
    }

    // --- MQTT Connection Logic ---
    function connectToBroker() {
        if (client && client.isConnected()) {
            client.disconnect();
            return;
        }

        // IMPORTANT: The "broker" is your Node-RED server's address.
        // The port is the one Node-RED uses for its WebSocket endpoint (default 1884 or as configured).
        const MQTT_BROKER = brokerAddressInput.value.trim();
        const MQTT_PORT = 9001; // Default Node-RED WebSocket port might be different, adjust if needed
        const MQTT_CLIENT_ID = "pwa_client_" + Math.random().toString(16).substr(2, 8);

        if (!MQTT_BROKER) {
            showToast("Server address cannot be empty!", true);
            return;
        }

        mqttStatusEl.textContent = `Connecting to ${MQTT_BROKER}...`;
        mqttStatusEl.style.color = 'orange';

        client = new Paho.Client(MQTT_BROKER, MQTT_PORT, MQTT_CLIENT_ID);
        client.onConnectionLost = onConnectionLost;
        client.onMessageArrived = onMessageArrived;

        client.connect({
            onSuccess: onConnect,
            onFailure: onFailure,
            useSSL: false,
            timeout: 5
        });
    }

    connectBtn.addEventListener('click', connectToBroker);

    // --- MQTT Callback Functions ---
    function onConnect() {
        console.log("Connected to Node-RED WebSocket!");
        showToast("Connected to Server!");
        mqttStatusEl.textContent = `Connected to ${client.host}`;
        mqttStatusEl.style.color = 'green';
        connectBtn.textContent = "Disconnect";
        // Subscribe to topics exposed by Node-RED
        client.subscribe("esp32/ecg");
        client.subscribe("server/CADstatus"); // As defined in your Node-RED flow
    }

    function onFailure(response) {
        console.error("Connection failed: " + response.errorMessage);
        showToast('Connection Failed! Check server address and port.', true);
        mqttStatusEl.textContent = "Connection Failed";
        mqttStatusEl.style.color = 'red';
        connectBtn.textContent = "Connect";
        client = null;
    }

    function onConnectionLost(responseObject) {
        if (responseObject.errorCode !== 0) {
            console.log("Connection lost: " + responseObject.errorMessage);
            showToast("Connection Lost!", true);
            mqttStatusEl.textContent = "Disconnected";
            mqttStatusEl.style.color = 'red';
            connectBtn.textContent = "Connect";
            client = null;
        }
    }

    function onMessageArrived(message) {
        const topic = message.destinationName;
        const payload = message.payloadString;
        try {
            switch (topic) {
                case "esp32/ecg":
                    const ecgValue = parseFloat(payload);
                    if (!isNaN(ecgValue)) {
                        addDataToChart(ecgChart, new Date().toLocaleTimeString(), ecgValue);
                    }
                    break;
                
                case "server/CADstatus":
                    try {
                        const data = JSON.parse(payload);
                        if (data && data.prediction && data.patientID) {
                            const patientID = data.patientID;
                            const timestamp = data.timestamp || "No Timestamp";
                            const prediction = data.prediction;
                            const status = prediction.status || "N/A";
                            const risk = prediction.risk || "N/A";
                            const confidence = parseFloat(prediction.confidence) || 0;
                            const formattedConfidence = confidence.toFixed(2);
    
                            // *** MODIFICATION START ***
                            // Add a <br> at the beginning to ensure this block starts on a new line,
                            // separate from the "CAD Status:" label.
                            const statusHtml = `
                                <br>
                                Patient ID: <b>${patientID}</b><br>
                                Timestamp: <b>${timestamp}</b><br><br>
                                Status: <b>${status}</b><br>
                                Confidence: <b>${formattedConfidence}%</b><br>
                                Risk Level: <b>${risk}</b>
                            `;
                            // *** MODIFICATION END ***
                            
                            cadStatusEl.innerHTML = statusHtml;
                        } else {
                            cadStatusEl.textContent = "Waiting for complete prediction data...";
                        }
                    } catch (error) {
                        console.error("Error parsing CADstatus JSON:", error);
                        cadStatusEl.textContent = payload; 
                    }
                    break;

                default:
                    console.log(`Unhandled message on topic ${topic}`);
            }
        } catch (e) {
            console.error("Error processing message:", e);
        }
    }

    // --- Form Submission Handling ---
    function handleFormSubmit(formId, topic) {
        const form = document.getElementById(formId);
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            if (client && client.isConnected()) {
                const formData = new FormData(form);
                const data = {};
                formData.forEach((value, key) => {
                    data[key] = form.elements[key].type === 'checkbox' ? form.elements[key].checked : value;
                });

                const message = new Paho.Message(JSON.stringify(data));
                message.destinationName = topic;
                client.send(message);

                showToast("Data submitted successfully!");
                form.reset();
            } else {
                showToast("Not connected. Please connect to the server first.", true);
            }
        });
    }

    handleFormSubmit('patient-details-form', 'esp32/patient/data');
    handleFormSubmit('chest-pain-form', 'cardiac/form/chestpain');

    // --- Toast Notification Utility ---
    function showToast(message, isError = false, duration = 3000) {
        toastEl.textContent = message;
        toastEl.style.backgroundColor = isError ? '#dc3545' : '#28a745';
        toastEl.classList.add('show');
        setTimeout(() => { toastEl.classList.remove('show'); }, duration);
    }
});